# Ejercicio 3
Demostrar el uso y funcionalidad de las etiquetas básicas de HTML creando un articulo sobre la película de disney Artemis Fowl
![]()